 
<footer id="footer" class="footer" style="padding:20px; margin-top:50px; ">
	<div class="container text-center">

		<ul class="social-links" style="margin:0px;padding:0px">
			<li><a href="#link"><i class="fa fa-twitter fa-fw"></i></a></li>
			<li><a href="#link"><i class="fa fa-facebook fa-fw"></i></a></li>
			<li><a href="#link"><i class="fa fa-google-plus fa-fw"></i></a></li>
			<li><a href="#link"><i class="fa fa-dribbble fa-fw"></i></a></li>
			<li><a href="#link"><i class="fa fa-linkedin fa-fw"></i></a></li>
		</ul>
		<!-- End newsletter-form -->
		<ul class="social-links" style="padding:0;margin-top:25px;">
			<li id="footerHome"><a href="index2.php" style="font-size: 15px ">Home</a></li>
			<li id="footerProfile"><a href="profile.php" style="font-size: 15px ">Profile</a></li>
			<li id="footerAbouts"><a href="abouts2.php" style="font-size: 15px ">About Us</a></li>
		</ul>
		©2018 OCPS All rights reserved
	</div>
</footer>
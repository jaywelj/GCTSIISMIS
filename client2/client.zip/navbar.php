
<nav class="navbar navbar-default navbar-fixed-top">
	<div class="container">
		<div class="navbar-header">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
			<a class="navbar-brand" href="index2.php">
				<span>O</span>CP<span>S</span>
			</a>
		</div>
		<div class="collapse navbar-collapse" id="myNavbar">
			<ul class="nav navbar-nav navbar-right">
				<li id="home"><a href="index2.php">Home</a></li>
				<li id="profile"><a href="profile.php">Profile</a></li>
				<li id="iir"><a href="individualInventory.php">Individual Inventory</a></li>
				<!-- <li id="survey"><a href="survey.php">Surveys</a></li> -->
				<li id="survey"><a href="problemSurvey.php">Surveys</a></li>
				<li id="abouts"><a href="abouts2.php">Abouts</a></li>
				<li id="abouts"><a href="logout.php">Logout</a></li>
				<!-- <li id="log-in"><a href="#" data-target="#login" data-toggle="modal">Login</a></li> -->

				<!-- <li class="btn-trial"><a href="#footer">Free Trail</a></li> -->
			</ul>
		</div>
	</div>
</nav>
<div class="jumbotron" style="background-color:#ffffff; height:100px; margin-bottom:0px; padding:7px; margin-top: 60px; border-bottom: solid 1px #f2dede;" >
	<image class="navbar-left" src="img/GCTS LOGO1.png"></image>
	<div style="font-family:'Cinzel'; font-weight:bold; margin-left:100px; color:#b22222;margin-top: 15px;">
		<h4 style="margin-bottom:0px;"><a href="index2.php" style="font-weight:bold; color:#880000;">POLYTECHNIC UNIVERSITY OF THE PHILIPPINES</a></h4>
		<p style="margin-bottom: 0; font-size: 14px;">THE COUNTRY'S 1ST POLYTECHNICU</p>
		<h4 style="margin-top: 0; font-weight: bold;">OFFICE OF COUNSELING AND PSYCHOLOGICAL SERVICES</h4>
	</div>
</div>
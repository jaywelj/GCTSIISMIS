<?php

$databaseHost = 'localhost';
$databaseName = 'ocps';
$databaseUsername = 'root';
$databasePassword = '';

$connect = mysqli_connect($databaseHost,$databaseUsername,$databasePassword,$databaseName);
?>

<form method="post" enctype="multipart/form-data">
	<div id="shortcut_note_Modal" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header" style="background: #800; color:#fff; margin-right: -1px;">
					<button type="button" class="close" data-dismiss="modal" style="color: #fff" >&times;</button>
					<h4 class="modal-title text-center">Significant Notes</h4>
				</div>
				<div class="modal-body" id="noteDetails"    style=" padding: 5px 50px 5px 50px;">

				</div>
				<div class="modal-footer">
					<input type="submit" name="btnAdd" id="btnAdd" value="Add Significant Note" class="btn btn-success " />
					<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
				</div>
			</div>
		</div>
	</div>
</form>

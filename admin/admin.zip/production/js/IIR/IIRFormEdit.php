<script>
var temp="<?php echo $varcharStudentSexuality;?>"; 
$("#dropdownSexuality").val(temp);
alert(temp);

</script>